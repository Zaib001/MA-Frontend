const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const Clothing = require('./models/clothing');
const User = require('./models/userModel');
const cloth = require('./data.js');
const connection = require('./database');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');

dotenv.config();

const app = express();
app.use(bodyParser.json());
app.use(cors());

app.use(express.json()); 

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(express.static('views'));

app.get('/home', async (req, res) => {
  try {
    const clothes = await Clothing.find();
    res.render('home.ejs', { clothes });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
app.get('/cart' , async (req,res) => {
  res.render('cart.ejs');
})
app.get('/forgetpass' , async (req,res) => {
  res.render('forgetpass.ejs');
})
app.get('/login' , async (req,res) => {
  res.render('login.ejs');
})
app.get('/search' , async (req,res) => {
  res.render('search.ejs');
})
app.get('/showcloth' , async (req,res) => {
  res.render('ShowCloth.ejs');
})
app.get('/signup' , async (req,res) => {
  res.render('signup.ejs');
})
app.post('/api/clothes', async (req, res) => {
  try {
    const newClothing = new Clothing(req.body);
    const savedClothing = await newClothing.save();
    res.status(201).json(savedClothing);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/clothes', async (req, res) => {
  try {
    const clothes = await Clothing.find();
    res.json(clothes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/clothes/:id', async (req, res) => {
  const itemId = req.params.id;

  try {
    // Check if the clothing item exists
    const clothingItem = await Clothing.findById(itemId);
    if (!clothingItem) {
      return res.status(404).json({ message: 'Clothing item not found' });
    }

    // Delete the clothing item
    await Clothing.findByIdAndDelete(itemId);

    res.json({ message: 'Clothing item deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await User.findOne({ username });

    if (!user) {
      return res.status(401).json({ message: 'Invalid username or password' });
    }
    const passwordMatch = await bcrypt.compare(password, user.password);

    if (!passwordMatch) {
      return res.status(401).json({ message: 'Invalid username or password' });
    }
    res.status(200).json({ message: 'Login successful' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


app.post('/api/register', async (req, res) => {
  try {
    const newUser = await User.create(req.body);
    res.status(201).json({ message: 'User registered successfully', user: newUser });
  } catch (error) {
    if (error.code === 11000) {
      res.status(400).json({ error: 'Username or email is already taken' });
    } else {
      res.status(400).json({ error: error.message });
    }
  }
});





app.get('/forgot-password', (req, res) => {
  res.render('forgotpass.ejs');
});


app.use((req, res) => {
  res.status(404).send('<h1>Error: 404</h1>');
});

connection();

const PORT = process.env.PORT || 4000; // Use a default port if not specified in .env
app.listen(PORT, () => {
  console.log(`Listening on port ${PORT}...`);
});
