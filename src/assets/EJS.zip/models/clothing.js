const mongoose = require('mongoose');

const clothingSchema = new mongoose.Schema({
  img: { type: String, required: true },
  alt: { type: String, required: true },
  type: { type: String, required: true },
  price: { type: Number, required: true },
});

const Clothing = mongoose.model('Clothing', clothingSchema);

module.exports = Clothing;
