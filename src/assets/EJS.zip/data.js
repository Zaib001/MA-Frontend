[
    {
      "img": "img/tshirt.jpeg",
      "alt": "white T-shirt",
      "type": "white T-shirt",
      "price": 29.99
    },
    {
      "img": "img/Jeans.jpeg",
      "alt": "Jeans pants",
      "type": "Jeans pants",
      "price": 59.99
    },
    {
      "img": "img/hoodie.jpeg",
      "alt": "Black hoodie",
      "type": "Black hoodie",
      "price": 39.99
    },
    {
      "img": "img/dress.jpeg",
      "alt": "White dress",
      "type": "White dress",
      "price": 89.99
    },
    {
      "img": "img/Skirt.avif",
      "alt": "Beige skirt",
      "type": "Beige skirt",
      "price": 61.99
    },
    {
      "img": "img/jacket.webp",
      "alt": "Beige jacket",
      "type": "Beige jacket",
      "price": 79.99
    }
  ]
  